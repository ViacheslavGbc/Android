package ca.georgebrown.comp3074.lab9;

import android.provider.BaseColumns;

public final class WordsContract {
    private WordsContract(){};
        public static class WordsEntity implements BaseColumns{
            public static final String TABLE_NAME = "words";
            public static final String COLUMN_NAME_WORD1 = "words1";
            public static final String COLUMN_NAME_WORD2 = "words2";

            public static final String SQL_CREATE = "CREATE TABLE " +
                    TABLE_NAME + " ( " + _ID + " INTEGER PRIMARY KEY, " +
                    COLUMN_NAME_WORD1 + " TEXT, " +
                    COLUMN_NAME_WORD2 + " TEXT)";

            public static final String SQL_DROP ="DROP TABLE IF EXITS " + TABLE_NAME;
        }
}
