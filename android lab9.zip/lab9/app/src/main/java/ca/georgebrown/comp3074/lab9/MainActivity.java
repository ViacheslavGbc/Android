package ca.georgebrown.comp3074.lab9;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WordsDpHelper dbHelper = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new WordsDpHelper(this);
        dbHelper.getReadableDatabase();


        final EditText word1 = findViewById(R.id.editText);
        final EditText word2 = findViewById(R.id.editText2);
        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v) {

                String w1 = word1.getText().toString();
                String w2 = word2.getText().toString();
                long id = addWord(w1, w2);

                Toast.makeText(v.getContext(),
                        "Element add with id = " + id, Toast.LENGTH_LONG).show();
                }
            });

        Cursor c = getAllWords();
        List list = new ArrayList<String>();

        while(c.moveToNext()){

            String w = c.getString(
                    c.getColumnIndexOrThrow(
                            WordsContract.WordsEntity.COLUMN_NAME_WORD1
                    )
            );
            list.add(w);

        }
        c.close();
        Log.d("DATABASE", "Number of elements in the db is " + list.size());
    }

    private long addWord(String w1, String w2){

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(WordsContract.WordsEntity.COLUMN_NAME_WORD1,w1);
        cv.put(WordsContract.WordsEntity.COLUMN_NAME_WORD1,w2);

        return db.insert(WordsContract.WordsEntity.TABLE_NAME, null, cv);
    }


    private Cursor getAllWords() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String [] projection = {

                WordsContract.WordsEntity._ID,
                WordsContract.WordsEntity.COLUMN_NAME_WORD1,
                WordsContract.WordsEntity.COLUMN_NAME_WORD2
        };

        String selection = null; //" word1 = ? ";
        String[] selectionArgs = null; //{"test"};

        return db.query(
                WordsContract.WordsEntity.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null // "COLUMN_NAME_WORD1 DESC"
        );
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
