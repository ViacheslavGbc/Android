package ca.georgebrown.comp3074.restaurants;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class AddNewRestaurant extends AppCompatActivity {

    public static  RestaurantManager.Restaurant restaurant;
    public ArrayList<Restaurant> restaurants;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_restaurant);

        final TextView txtName = findViewById(R.id.txtName);
        final TextView txtType = findViewById(R.id.txtType);
        final TextView txtAddress = findViewById(R.id.txtAddress);
        final TextView txtPhone = findViewById(R.id.txtPhone);
        final TextView txtWebsite = findViewById(R.id.txtWebsite);
        final TextView txtRate = findViewById(R.id.txtRate);
        final TextView txtPrice = findViewById(R.id.txtPrice);
        final TextView txtOtherTags = findViewById(R.id.txtOthersTags);
        Button btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = txtName.getText().toString();
                String type = txtType.getText().toString();
                String price = txtPrice.getText().toString();

                String address = txtAddress.getText().toString();
                String phone = txtPhone.getText().toString();
                String website = txtWebsite.getText().toString();
                String rate = txtRate.getText().toString();
                String otherTags = txtOtherTags.getText().toString();

                restaurant = RestaurantManager.createElement(name, type);
                restaurant.setPrice(price);
                restaurant.setAddress(address);
                restaurant.setPhone(phone);
                restaurant.setWebsite(website);
                restaurant.setRate(rate);
                restaurant.setOtherTags(otherTags);

                RestaurantManager.ITEMS.add(restaurant);
                //RestaurantManager.ITEM_MAP.put(restaurant.getId(), restaurant);

                finish();
            }
        });
    }
}
